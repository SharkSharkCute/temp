function list_string_split(input, delim)
  local t = {}
  local pos = 1
  while true do
    next_delim = string.find(input, delim, pos)
    if next_delim == nil then
      table.insert(t, string.sub(input, pos))
      break
    else
      table.insert(t, string.sub(input, pos, next_delim-1))
      pos = next_delim + #delim
    end
  end
  return t
end


set_global_var('test',(list_string_split('0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0', ',')))
info(serial_port_open(2,'flexiv_wib',57600,0,8,1))
while true do
  res = {}
  res = serial_port_recv(2,33)
  if #res ~= 0 then
    set_global_var('test',res)
  end
end
